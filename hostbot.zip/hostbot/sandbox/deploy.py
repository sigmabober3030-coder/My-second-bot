#!/usr/bin/env python3
"""Запускается ВНУТРИ одноразового контейнера: раскладывает код пользователя в /app/code.
Хост никогда не трогает файлы, которые мог изменить пользователь."""
import os
import shutil
import stat
import subprocess
import sys
import zipfile
from pathlib import Path

CODE = Path(os.getenv("CODE_DIR", "/app/code"))
TMP = CODE.parent / ".tmp_deploy"
MAX_TOTAL = 300 * 1024 * 1024
MAX_FILES = 5000


def fail(msg):
    print("ERROR:", msg)
    sys.exit(1)


def rm(p: Path):
    if p.is_symlink() or p.is_file():
        p.unlink()
    elif p.exists():
        shutil.rmtree(p)


def finish(root: Path):
    rm(CODE)
    CODE.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(root), str(CODE))
    rm(TMP)
    print("OK:", ", ".join(sorted(os.listdir(CODE))[:30]))


def do_zip(src):
    try:
        z = zipfile.ZipFile(src)
    except zipfile.BadZipFile:
        fail("это не zip-архив")
    infos = z.infolist()
    if len(infos) > MAX_FILES:
        fail(f"слишком много файлов (>{MAX_FILES})")
    if sum(i.file_size for i in infos) > MAX_TOTAL:
        fail("архив слишком большой после распаковки")
    for i in infos:
        p = Path(i.filename)
        if p.is_absolute() or ".." in p.parts:
            fail("небезопасный путь в архиве")
    rm(TMP)
    TMP.mkdir(parents=True)
    for i in infos:
        if stat.S_ISLNK(i.external_attr >> 16) or i.filename.startswith("__MACOSX"):
            continue
        z.extract(i, TMP)
    entries = list(TMP.iterdir())
    if len(entries) == 1 and entries[0].is_dir():
        finish(entries[0])
    else:
        finish(TMP)


def do_file(src, name):
    name = Path(name).name.lstrip(".")
    if not name:
        fail("плохое имя файла")
    CODE.mkdir(parents=True, exist_ok=True)
    target = CODE / name
    rm(target)
    shutil.copyfile(src, target)
    print("OK:", ", ".join(sorted(os.listdir(CODE))[:30]))


def do_git(url):
    rm(TMP)
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0", "GIT_ALLOW_PROTOCOL": "https"}
    try:
        r = subprocess.run(
            ["git", "clone", "--depth", "1", "--single-branch", "--no-tags", "--", url, str(TMP)],
            env=env, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        fail("git clone: таймаут")
    if r.returncode:
        fail("git clone: " + r.stderr[-400:])
    shutil.rmtree(TMP / ".git", ignore_errors=True)
    finish(TMP)


if __name__ == "__main__":
    os.makedirs(os.getenv("HOME", "/app/home"), exist_ok=True)
    mode, arg = sys.argv[1], sys.argv[2]
    if mode == "zip":
        do_zip(arg)
    elif mode == "file":
        do_file(arg, sys.argv[3])
    elif mode == "git":
        do_git(arg)
    else:
        fail("неизвестный режим")

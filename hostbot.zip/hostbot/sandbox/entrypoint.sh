#!/bin/sh
mkdir -p /app/home /app/data
cd /app/code 2>/dev/null || { echo "[hostbot] Кода нет. Пришли файлы боту-менеджеру."; exit 78; }

ENTRY=""
for f in main.py bot.py app.py run.py; do
  if [ -f "$f" ]; then ENTRY="$f"; break; fi
done
[ -z "$ENTRY" ] && { echo "[hostbot] Не найден main.py (или bot.py / app.py / run.py)."; exit 78; }

if [ -f requirements.txt ]; then
  H=$(sha256sum requirements.txt | cut -d' ' -f1)
  if [ "$H" != "$(cat /app/.req_hash 2>/dev/null)" ]; then
    echo "[hostbot] Устанавливаю зависимости..."
    rm -rf /app/.deps
    pip install --no-cache-dir --target /app/.deps -r requirements.txt \
      || { echo "[hostbot] pip install не удался"; exit 1; }
    echo "$H" > /app/.req_hash
  fi
fi

echo "[hostbot] Запуск $ENTRY"
exec python -u "$ENTRY"

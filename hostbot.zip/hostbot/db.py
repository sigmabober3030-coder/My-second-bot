import os
import sqlite3
import time
from contextlib import closing

import config as C


def _q(sql, args=(), one=False, write=False):
    with closing(sqlite3.connect(C.DB_PATH, timeout=10)) as c:
        c.row_factory = sqlite3.Row
        cur = c.execute(sql, args)
        if write:
            c.commit()
            return cur.lastrowid
        rows = cur.fetchall()
        return (rows[0] if rows else None) if one else rows


def init():
    _q("""CREATE TABLE IF NOT EXISTS bots(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        tg_username TEXT,
        bot_username TEXT,
        token TEXT NOT NULL,
        desired TEXT NOT NULL DEFAULT 'stopped',
        created_at INTEGER NOT NULL)""", write=True)
    if "uid" not in [r["name"] for r in _q("PRAGMA table_info(bots)")]:
        _q("ALTER TABLE bots ADD COLUMN uid INTEGER", write=True)
    _q("""CREATE TABLE IF NOT EXISTS users(
        user_id INTEGER PRIMARY KEY,
        tg_username TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        rules_ok INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL)""", write=True)
    os.chmod(C.DB_PATH, 0o600)  # тут лежат токены


# ---------- боты ----------

def create(user_id, tg_username, token, bot_username):
    i = _q("INSERT INTO bots(user_id,tg_username,bot_username,token,created_at) VALUES(?,?,?,?,?)",
           (user_id, tg_username, bot_username, token, int(time.time())), write=True)
    _q("UPDATE bots SET uid=? WHERE id=?", (C.UID_BASE + i, i), write=True)
    return i


def get(bot_id):
    return _q("SELECT * FROM bots WHERE id=?", (bot_id,), one=True)


def by_user(user_id):
    return _q("SELECT * FROM bots WHERE user_id=?", (user_id,))


def all_bots():
    return _q("SELECT * FROM bots ORDER BY id")


def count():
    return _q("SELECT COUNT(*) c FROM bots", one=True)["c"]


def token_taken(token, bot_id=None):
    return _q("SELECT 1 FROM bots WHERE token=? AND id IS NOT ?", (token, bot_id), one=True) is not None


def set_desired(bot_id, value):
    _q("UPDATE bots SET desired=? WHERE id=?", (value, bot_id), write=True)


def set_uid(bot_id, uid):
    _q("UPDATE bots SET uid=? WHERE id=?", (uid, bot_id), write=True)


def set_token(bot_id, token, username):
    _q("UPDATE bots SET token=?, bot_username=? WHERE id=?", (token, username, bot_id), write=True)


def delete(bot_id):
    _q("DELETE FROM bots WHERE id=?", (bot_id,), write=True)


# ---------- пользователи ----------

def user(user_id):
    return _q("SELECT * FROM users WHERE user_id=?", (user_id,), one=True)


def upsert_user(user_id, username, status):
    now = int(time.time())
    if user(user_id) is None:
        _q("INSERT INTO users(user_id,tg_username,status,rules_ok,updated_at) VALUES(?,?,?,0,?)",
           (user_id, username, status, now), write=True)
    else:
        _q("UPDATE users SET tg_username=?, status=?, updated_at=? WHERE user_id=?",
           (username, status, now, user_id), write=True)


def set_status(user_id, status):
    if user(user_id) is None:
        upsert_user(user_id, None, status)
    else:
        _q("UPDATE users SET status=?, updated_at=? WHERE user_id=?",
           (status, int(time.time()), user_id), write=True)


def accept_rules(user_id):
    _q("UPDATE users SET rules_ok=1 WHERE user_id=?", (user_id,), write=True)


def pending_users():
    return _q("SELECT * FROM users WHERE status='pending'")

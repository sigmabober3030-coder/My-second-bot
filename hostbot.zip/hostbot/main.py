import asyncio
import html
import logging
import re
import shutil
import time
from pathlib import Path

import aiohttp
from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (BotCommand, CallbackQuery, InlineKeyboardButton as Btn,
                           InlineKeyboardMarkup, Message)

import config as C
import db
import dockerctl as dc

log = logging.getLogger("hostbot")
router = Router()
MB = 1024 * 1024
TOKEN_RE = re.compile(r"^\d{6,12}:[A-Za-z0-9_-]{30,50}$")
GIT_RE = re.compile(r"^https://[A-Za-z0-9.\-]+(:\d+)?/[A-Za-z0-9._~/\-]+$")

_locks: dict[int, asyncio.Lock] = {}
_create_lock = asyncio.Lock()
_restarts: dict[int, list[float]] = {}


def lock(i):
    return _locks.setdefault(i, asyncio.Lock())


class Form(StatesGroup):
    token = State()


PANEL = InlineKeyboardMarkup(inline_keyboard=[
    [Btn(text="📊 Статус", callback_data="a:status"), Btn(text="📜 Логи", callback_data="a:logs")],
    [Btn(text="▶️ Старт / рестарт", callback_data="a:start"), Btn(text="⏹ Стоп", callback_data="a:stop")],
    [Btn(text="🗑 Удалить", callback_data="a:delete")],
])
CONFIRM = InlineKeyboardMarkup(inline_keyboard=[[
    Btn(text="Да, удалить", callback_data="a:delete_yes"), Btn(text="Отмена", callback_data="a:status")]])

HELP = (
    "Хостю маленьких Telegram-ботов на <b>Python</b>.\n"
    f"Лимиты: {C.MEM_MB} МБ RAM, {C.CPU} CPU, {C.DISK_MB} МБ диска.\n\n"
    "1. /new — создать бота (нужен токен от @BotFather)\n"
    "2. Пришли код: <b>.zip</b>, файлы (<code>main.py</code>, <code>requirements.txt</code>) "
    "или https-ссылку на git-репозиторий\n"
    "3. Нажми ▶️ в /panel\n\n"
    "Точка входа: main.py (или bot.py / app.py / run.py). Токен лежит в переменной <code>BOT_TOKEN</code>.\n"
    "Данные храни в <code>/app/data</code> (переменная <code>DATA_DIR</code>): папка с кодом "
    "при обновлении перезаписывается.\n\n"
    "/status /logs /run /stop /token /delete"
)


def my_bot(user_id):
    rows = db.by_user(user_id)
    return rows[0] if rows else None


def fmt_dur(sec):
    sec = int(sec)
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m = r // 60
    return (f"{d}д " if d else "") + (f"{h}ч " if h else "") + f"{m}м"


async def check_token(token):
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as s:
            async with s.get(f"https://api.telegram.org/bot{token}/getMe") as r:
                j = await r.json()
        return j["result"]["username"] if j.get("ok") else None
    except Exception:
        return None


# ---------- действия ----------

async def act_status(row):
    i = row["id"]
    st = await asyncio.to_thread(dc.state, i)
    used, total = await asyncio.to_thread(dc.disk_usage, i)
    extra = ""
    if st and st["status"] == "running":
        line = f"🟢 работает ({fmt_dur(time.time() - st['started_at'])})"
        try:
            s = await asyncio.to_thread(dc.stats, i)
            extra = f"\nRAM: {s['mem'] // MB} / {C.MEM_MB} МБ\nCPU: {s['cpu']:.0f}%"
        except Exception:
            pass
    elif st and st["oom"]:
        line = "💥 остановлен: не хватило памяти"
    elif st:
        line = f"🔴 остановлен (код {st['exit_code']})"
    else:
        line = "🔴 остановлен"
    return f"🤖 @{row['bot_username']}\n{line}{extra}\nДиск: {used // MB} / {total // MB} МБ"


async def act_logs(row):
    raw = await asyncio.to_thread(dc.logs, row["id"], 60)
    raw = raw.replace(row["token"], "***")[-3500:].strip()
    return f"<pre>{html.escape(raw)}</pre>" if raw else "Логов пока нет."


async def act_start(row):
    async with lock(row["id"]):
        try:
            await asyncio.to_thread(dc.start, row["id"], row["token"])
        except Exception as e:
            log.exception("start failed")
            return f"Не удалось запустить: {html.escape(str(e))[:300]}"
        db.set_desired(row["id"], "running")
        _restarts.pop(row["id"], None)
    return "🟢 Запускаю. Через несколько секунд глянь /logs (первый запуск ставит зависимости)."


async def act_stop(row):
    async with lock(row["id"]):
        db.set_desired(row["id"], "stopped")
        await asyncio.to_thread(dc.stop, row["id"])
    return "⏹ Остановлен."


async def act_delete(row):
    async with lock(row["id"]):
        await asyncio.to_thread(dc.destroy, row["id"])
        db.delete(row["id"])
    return "🗑 Бот и все его файлы удалены. Новый слот: /new"


async def run_action(msg: Message, user_id: int, action: str):
    row = my_bot(user_id)
    if not row:
        await msg.answer("У тебя пока нет бота. Создай: /new")
        return
    kb = PANEL
    if action == "status":
        text = await act_status(row)
    elif action == "logs":
        text = await act_logs(row)
    elif action == "start":
        text = await act_start(row)
    elif action == "stop":
        text = await act_stop(row)
    elif action == "delete":
        text, kb = "Точно удалить бота и все его файлы? Это необратимо.", CONFIRM
    elif action == "delete_yes":
        text, kb = await act_delete(row), None
    else:
        return
    await msg.answer(text, reply_markup=kb)


def _mk(act):
    async def h(m: Message):
        await run_action(m, m.from_user.id, act)
    return h


for _cmd, _act in {"status": "status", "panel": "status", "logs": "logs", "run": "start",
                   "restart": "start", "stop": "stop", "delete": "delete"}.items():
    router.message.register(_mk(_act), Command(_cmd))


@router.callback_query(F.data.startswith("a:"))
async def on_cb(c: CallbackQuery):
    await c.answer()
    await run_action(c.message, c.from_user.id, c.data[2:])


# ---------- команды ----------

@router.message(CommandStart())
@router.message(Command("help"))
async def cmd_start(m: Message):
    await m.answer(HELP)


@router.message(Command("cancel"))
async def cmd_cancel(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("Отменено.")


@router.message(Command("new"))
async def cmd_new(m: Message, state: FSMContext):
    if len(db.by_user(m.from_user.id)) >= C.BOTS_PER_USER:
        await m.answer("У тебя уже есть бот: /panel. Чтобы создать другого, сначала /delete.")
        return
    if db.count() >= C.MAX_BOTS:
        await m.answer("Свободных слотов сейчас нет 😔")
        return
    await state.set_state(Form.token)
    await state.update_data(mode="new")
    await m.answer("Пришли токен бота от @BotFather (сообщение с токеном я сразу удалю). /cancel — отмена.")


@router.message(Command("token"))
async def cmd_token(m: Message, state: FSMContext):
    if not my_bot(m.from_user.id):
        await m.answer("Сначала /new")
        return
    await state.set_state(Form.token)
    await state.update_data(mode="change")
    await m.answer("Пришли новый токен. /cancel — отмена.")


@router.message(Command("admin"))
async def cmd_admin(m: Message):
    if m.from_user.id not in C.ADMIN_IDS:
        return
    rows = db.all_bots()
    free = shutil.disk_usage(C.DATA_DIR).free // (1024 * MB)
    lines = [f"Слотов: {len(rows)}/{C.MAX_BOTS}, диск свободно: {free} ГБ, режим диска: {dc.disk_mode}"]
    for r in rows:
        lines.append(f"#{r['id']} user {r['user_id']} @{r['tg_username']} → @{r['bot_username']} [{r['desired']}]")
    lines.append("\n/admin_del &lt;id&gt; — удалить бота")
    await m.answer("\n".join(lines))


@router.message(Command("admin_del"))
async def cmd_admin_del(m: Message):
    if m.from_user.id not in C.ADMIN_IDS:
        return
    try:
        row = db.get(int(m.text.split()[1]))
    except Exception:
        row = None
    if not row:
        await m.answer("Не нашёл. Формат: /admin_del 3")
        return
    await act_delete(row)
    await m.answer("Удалён.")


# ---------- токен ----------

@router.message(Form.token, F.text)
async def got_token(m: Message, state: FSMContext):
    token = m.text.strip()
    try:
        await m.delete()
    except Exception:
        pass
    data = await state.get_data()
    uid = m.from_user.id
    if not TOKEN_RE.match(token):
        await m.answer("Не похоже на токен. Пришли ещё раз или /cancel.")
        return
    if token.split(":")[0] == C.BOT_TOKEN.split(":")[0]:
        await m.answer("Это токен самого менеджера, нужен токен ДРУГОГО бота.")
        return
    row = my_bot(uid)
    if db.token_taken(token, row["id"] if row else None):
        await m.answer("Этот токен уже используется.")
        return
    username = await check_token(token)
    if not username:
        await m.answer("Telegram не принял этот токен. Проверь и пришли ещё раз.")
        return

    if data.get("mode") == "change" and row:
        db.set_token(row["id"], token, username)
        await state.clear()
        txt = f"Токен обновлён: @{username}."
        if row["desired"] == "running":
            await act_start(db.get(row["id"]))
            txt += " Бот перезапущен."
        await m.answer(txt, reply_markup=PANEL)
        return

    async with _create_lock:
        if len(db.by_user(uid)) >= C.BOTS_PER_USER or db.count() >= C.MAX_BOTS:
            await state.clear()
            await m.answer("Не получилось: нет свободных слотов.")
            return
        bot_id = db.create(uid, m.from_user.username, token, username)
        try:
            await asyncio.to_thread(dc.create_disk, bot_id)
        except Exception:
            log.exception("create_disk failed")
            await asyncio.to_thread(dc.destroy, bot_id)
            db.delete(bot_id)
            await state.clear()
            await m.answer("Ошибка при создании диска, сообщи админу.")
            return
    await state.clear()
    await m.answer(f"✅ Слот создан для @{username}.\nТеперь пришли код: .zip, файлы "
                   "(main.py, requirements.txt) или https-ссылку на git. Потом жми ▶️.", reply_markup=PANEL)


# ---------- загрузка кода ----------

async def do_deploy(bot_id, mode, arg, stage=None, extra=None):
    async with lock(bot_id):
        row = db.get(bot_id)
        was_running = row["desired"] == "running"
        await asyncio.to_thread(dc.stop, bot_id)
        try:
            ok, out = await asyncio.to_thread(dc.run_deploy, bot_id, mode, arg, stage, extra)
        except Exception as e:
            ok, out = False, str(e)
        if stage:
            shutil.rmtree(stage, ignore_errors=True)
        if ok and was_running:
            await asyncio.to_thread(dc.start, bot_id, row["token"])
    return ok, out, was_running


def result_text(ok, out, was_running):
    out = html.escape(out)
    if not ok:
        return f"❌ Не получилось:\n<pre>{out}</pre>"
    tail = "Бот перезапущен." if was_running else "Жми ▶️ чтобы запустить."
    return f"✅ Готово. Файлы: <code>{out.removeprefix('OK: ')}</code>\n{tail}"


@router.message(F.document)
async def got_document(m: Message, bot: Bot):
    row = my_bot(m.from_user.id)
    if not row:
        await m.answer("Сначала создай бота: /new")
        return
    d = m.document
    name = d.file_name or "file"
    is_zip = name.lower().endswith(".zip")
    if d.file_size and d.file_size > (20 if is_zip else 5) * MB:
        await m.answer("Файл слишком большой (zip до 20 МБ, одиночные файлы до 5 МБ).")
        return
    safe = re.sub(r"[^\w.\-]", "_", Path(name).name).lstrip(".")[:80]
    if not is_zip and not safe:
        await m.answer("Странное имя файла.")
        return
    stage = C.STAGE_DIR / str(row["id"])
    shutil.rmtree(stage, ignore_errors=True)
    stage.mkdir(parents=True)
    status = await m.answer("⏳ Загружаю…")
    await bot.download(d, destination=stage / "upload.bin")
    ok, out, was = await do_deploy(row["id"], "zip" if is_zip else "file", "/in/upload.bin", stage,
                                   None if is_zip else safe)
    await status.edit_text(result_text(ok, out, was))


@router.message(F.text.regexp(r"^https://\S+$"))
async def got_git(m: Message):
    row = my_bot(m.from_user.id)
    if not row:
        await m.answer("Сначала создай бота: /new")
        return
    url = m.text.strip()
    if not GIT_RE.match(url):
        await m.answer("Нужна ссылка вида https://github.com/user/repo")
        return
    status = await m.answer("⏳ Клонирую…")
    ok, out, was = await do_deploy(row["id"], "git", url)
    await status.edit_text(result_text(ok, out, was))


@router.message()
async def fallback(m: Message):
    await m.answer("Не понял 🤔 Список команд: /help")


# ---------- сторожевой таймер ----------

async def notify(bot: Bot, row, text):
    try:
        await bot.send_message(row["user_id"], text)
    except Exception:
        log.warning("не смог написать %s", row["user_id"])


async def check_all(bot: Bot, tick: int):
    for row in db.all_bots():
        if row["desired"] != "running":
            continue
        i = row["id"]
        async with lock(i):
            st = await asyncio.to_thread(dc.state, i)
            if st is None:
                await asyncio.to_thread(dc.start, i, row["token"])
                continue
            if st["status"] == "running":
                if dc.disk_mode == "du" and tick % 2 == 0:
                    used, total = await asyncio.to_thread(dc.disk_usage, i)
                    if used > total:
                        db.set_desired(i, "stopped")
                        await asyncio.to_thread(dc.stop, i)
                        await notify(bot, row, f"⚠️ Бот остановлен: диск превысил {C.DISK_MB} МБ.")
                continue
            if st["status"] not in ("exited", "dead"):
                continue
            code = st["exit_code"]
            tail = html.escape((await asyncio.to_thread(dc.logs, i, 15)).replace(row["token"], "***")[-800:])
            if code in (0, 78) or st["oom"]:
                db.set_desired(i, "stopped")
                why = ("💥 не хватило памяти" if st["oom"] else
                       "завершился сам" if code == 0 else "нет кода или main.py")
                await notify(bot, row, f"⏹ Бот остановлен: {why}.\n<pre>{tail}</pre>")
                continue
            now = time.time()
            hist = [t for t in _restarts.get(i, []) if now - t < 600]
            if len(hist) >= 5:
                db.set_desired(i, "stopped")
                await notify(bot, row, f"🔁 Бот падает слишком часто, остановил.\n<pre>{tail}</pre>")
            else:
                hist.append(now)
                _restarts[i] = hist
                await asyncio.to_thread(dc.start, i, row["token"])


async def watchdog(bot: Bot):
    tick = 0
    while True:
        await asyncio.sleep(30)
        tick += 1
        try:
            await check_all(bot, tick)
        except Exception:
            log.exception("watchdog")


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    C.DATA_DIR.mkdir(parents=True, exist_ok=True)
    db.init()
    await asyncio.to_thread(dc.bootstrap)
    for row in db.all_bots():  # после перезагрузки: смонтировать диски и поднять нужные боты
        try:
            await asyncio.to_thread(dc.ensure_mounted, row["id"])
            if row["desired"] == "running":
                await asyncio.to_thread(dc.start, row["id"], row["token"])
        except Exception:
            log.exception("restore #%s failed", row["id"])
    bot = Bot(C.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    await bot.set_my_commands([
        BotCommand(command="new", description="Создать бота"),
        BotCommand(command="panel", description="Панель управления"),
        BotCommand(command="logs", description="Логи"),
        BotCommand(command="run", description="Запустить / перезапустить"),
        BotCommand(command="stop", description="Остановить"),
        BotCommand(command="help", description="Справка"),
    ])
    dp = Dispatcher()
    dp.include_router(router)
    asyncio.create_task(watchdog(bot))
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())

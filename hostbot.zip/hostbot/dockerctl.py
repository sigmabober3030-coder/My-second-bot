"""Всё, что касается Docker, дисков и фаервола. Синхронный код: из бота зовётся через to_thread."""
import logging
import os
import shutil
import subprocess
from datetime import datetime, timezone

import docker
from docker.errors import NotFound
from docker.types import IPAMConfig, IPAMPool, LogConfig, Ulimit

import config as C

log = logging.getLogger("dockerctl")
client = docker.from_env()
disk_mode = C.DISK_MODE if C.DISK_MODE != "auto" else "loop"


def _run(cmd):
    return subprocess.run(cmd, check=True, capture_output=True, text=True)


def cname(bot_id):
    return f"hb-{bot_id}"


def mnt(bot_id):
    return C.MNT_DIR / str(bot_id)


def img(bot_id):
    return C.DISKS_DIR / f"{bot_id}.img"


# ---------- диски ----------

def is_mounted(path):
    p = os.path.realpath(path)
    with open("/proc/mounts") as f:
        return any(line.split()[1] == p for line in f)


def _detect_disk_mode():
    global disk_mode
    if C.DISK_MODE != "auto":
        disk_mode = C.DISK_MODE
        return
    t = C.DATA_DIR / "looptest"
    m = C.DATA_DIR / "looptest_mnt"
    shutil.rmtree(t, ignore_errors=True)
    t.mkdir(parents=True)
    m.mkdir(exist_ok=True)
    try:
        with open(t / "t.img", "wb") as f:
            f.truncate(16 * 1024 * 1024)
        _run(["mkfs.ext4", "-q", "-F", str(t / "t.img")])
        _run(["mount", "-o", "loop", str(t / "t.img"), str(m)])
        _run(["umount", str(m)])
        disk_mode = "loop"
    except Exception as e:
        log.warning("loop-монтирование недоступно (%s) -> режим 'du' (мягкий лимит диска)", e)
        disk_mode = "du"
    finally:
        shutil.rmtree(t, ignore_errors=True)
        shutil.rmtree(m, ignore_errors=True)
    log.info("Режим диска: %s", disk_mode)


def ensure_mounted(bot_id):
    m = mnt(bot_id)
    m.mkdir(parents=True, exist_ok=True)
    if disk_mode == "loop" and not is_mounted(m):
        _run(["mount", "-o", "loop,nosuid,nodev", str(img(bot_id)), str(m)])


def create_disk(bot_id):
    m = mnt(bot_id)
    m.mkdir(parents=True, exist_ok=True)
    if disk_mode == "loop":
        with open(img(bot_id), "wb") as f:
            f.truncate(C.DISK_MB * 1024 * 1024)  # sparse-файл
        _run(["mkfs.ext4", "-q", "-F", "-m", "0", str(img(bot_id))])
        _run(["mount", "-o", "loop,nosuid,nodev", str(img(bot_id)), str(m)])
    os.chown(m, C.UID, C.UID)
    os.chmod(m, 0o750)


def disk_usage(bot_id):
    m = mnt(bot_id)
    if disk_mode == "loop":
        u = shutil.disk_usage(m)
        return u.used, u.total
    r = subprocess.run(["du", "-sb", str(m)], capture_output=True, text=True)
    return int(r.stdout.split()[0]), C.DISK_MB * 1024 * 1024


# ---------- сеть и фаервол ----------

def setup_network():
    try:
        client.networks.get(C.NETWORK)
    except NotFound:
        client.networks.create(
            C.NETWORK, driver="bridge",
            ipam=IPAMConfig(pool_configs=[IPAMPool(subnet=C.SUBNET)]),
            options={"com.docker.network.bridge.enable_icc": "false",   # контейнеры не видят друг друга
                     "com.docker.network.bridge.name": C.BRIDGE})


def _ipt(*rule):
    if subprocess.run(["iptables", "-C", *rule], capture_output=True).returncode != 0:
        subprocess.run(["iptables", "-I", *rule], check=True, capture_output=True)


def setup_firewall():
    """Контейнеры не должны ходить ни на хост, ни в локальные сети (только в интернет)."""
    try:
        for net in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16", "100.64.0.0/10"):
            _ipt("DOCKER-USER", "-i", C.BRIDGE, "-d", net, "-j", "DROP")
        _ipt("INPUT", "-i", C.BRIDGE, "-j", "DROP")
        _ipt("INPUT", "-i", C.BRIDGE, "-m", "conntrack", "--ctstate", "ESTABLISHED,RELATED", "-j", "ACCEPT")
        log.info("Фаервол настроен")
    except Exception as e:
        log.error("НЕ УДАЛОСЬ настроить iptables: %s. Контейнеры смогут достучаться до хоста!", e)


def ensure_image():
    try:
        client.images.get(C.IMAGE)
    except NotFound:
        log.info("Собираю базовый образ (пара минут)...")
        client.images.build(path=str(C.SANDBOX_DIR), tag=C.IMAGE, rm=True)


def bootstrap():
    for d in (C.DATA_DIR, C.DISKS_DIR, C.MNT_DIR, C.STAGE_DIR):
        d.mkdir(parents=True, exist_ok=True)
    _detect_disk_mode()
    setup_network()
    setup_firewall()
    ensure_image()


# ---------- контейнеры ----------

def _limits():
    return dict(
        user=f"{C.UID}:{C.UID}", read_only=True,
        tmpfs={"/tmp": "rw,nosuid,size=64m"},
        mem_limit=f"{C.MEM_MB}m", memswap_limit=f"{C.MEM_MB}m",
        nano_cpus=int(C.CPU * 1e9), pids_limit=C.PIDS,
        cap_drop=["ALL"], security_opt=["no-new-privileges"], init=True,
        ulimits=[Ulimit(name="nofile", soft=1024, hard=1024)],
        log_config=LogConfig(type="json-file", config={"max-size": "1m", "max-file": "2"}),
    )


def _env(extra=None):
    e = {"HOME": "/app/home", "PYTHONPATH": "/app/.deps", "PYTHONUNBUFFERED": "1",
         "DATA_DIR": "/app/data", "PIP_NO_CACHE_DIR": "1", "PIP_DISABLE_PIP_VERSION_CHECK": "1"}
    e.update(extra or {})
    return e


def get(bot_id):
    try:
        return client.containers.get(cname(bot_id))
    except NotFound:
        return None


def remove(bot_id):
    c = get(bot_id)
    if c:
        c.remove(force=True)


def start(bot_id, token):
    ensure_mounted(bot_id)
    remove(bot_id)
    client.containers.run(
        C.IMAGE, ["/entrypoint.sh"], name=cname(bot_id), detach=True, working_dir="/",
        network=C.NETWORK, dns=C.DNS,
        environment=_env({"BOT_TOKEN": token, "TELEGRAM_BOT_TOKEN": token}),
        volumes={str(mnt(bot_id)): {"bind": "/app", "mode": "rw"}},
        **_limits())


def stop(bot_id):
    c = get(bot_id)
    if c and c.status == "running":
        c.stop(timeout=10)


def _ts(s):
    try:
        return datetime.strptime(s[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc).timestamp()
    except Exception:
        return 0


def state(bot_id):
    c = get(bot_id)
    if not c:
        return None
    s = c.attrs["State"]
    return {"status": s["Status"], "exit_code": s.get("ExitCode"),
            "oom": s.get("OOMKilled", False), "started_at": _ts(s.get("StartedAt", ""))}


def logs(bot_id, tail=60):
    c = get(bot_id)
    return c.logs(tail=tail).decode(errors="replace") if c else ""


def stats(bot_id):
    c = get(bot_id)
    s = c.stats(stream=False)
    mem = s["memory_stats"].get("usage", 0)
    st = s["memory_stats"].get("stats", {})
    mem -= st.get("inactive_file", st.get("total_inactive_file", 0))
    cpu_d = s["cpu_stats"]["cpu_usage"]["total_usage"] - s["precpu_stats"]["cpu_usage"]["total_usage"]
    sys_d = s["cpu_stats"].get("system_cpu_usage", 0) - s["precpu_stats"].get("system_cpu_usage", 0)
    ncpu = s["cpu_stats"].get("online_cpus") or 1
    return {"mem": max(mem, 0), "cpu": (cpu_d / sys_d * ncpu * 100) if sys_d > 0 else 0.0}


def run_deploy(bot_id, mode, arg, stage_dir=None, extra=None):
    """Одноразовый контейнер с теми же лимитами. Возвращает (ok, вывод)."""
    ensure_mounted(bot_id)
    vols = {str(mnt(bot_id)): {"bind": "/app", "mode": "rw"}}
    if stage_dir:
        vols[str(stage_dir)] = {"bind": "/in", "mode": "ro"}
    net = {"network": C.NETWORK, "dns": C.DNS} if mode == "git" else {"network_mode": "none"}
    cmd = ["python", "/deploy.py", mode, arg] + ([extra] if extra else [])
    c = client.containers.run(C.IMAGE, cmd, detach=True, working_dir="/", volumes=vols,
                              environment=_env(), **net, **_limits())
    try:
        code = c.wait(timeout=180)["StatusCode"]
    except Exception:
        c.kill()
        code = 124
    out = c.logs().decode(errors="replace").strip()[-1500:]
    c.remove(force=True)
    return code == 0, out or ("таймаут" if code == 124 else f"код {code}")


def destroy(bot_id):
    remove(bot_id)
    m = mnt(bot_id)
    if disk_mode == "loop" and m.exists() and is_mounted(m):
        r = subprocess.run(["umount", str(m)], capture_output=True)
        if r.returncode:
            subprocess.run(["umount", "-l", str(m)], capture_output=True)
    img(bot_id).unlink(missing_ok=True)
    shutil.rmtree(m, ignore_errors=True)
    shutil.rmtree(C.STAGE_DIR / str(bot_id), ignore_errors=True)

"""Всё, что касается Docker, дисков и фаервола. Синхронный код: из бота зовётся через to_thread."""
import logging
import os
import shutil
import subprocess
from datetime import datetime, timezone

import docker
from docker.errors import NotFound
from docker.types import IPAMConfig, IPAMPool, LogConfig, Ulimit

import config as C

log = logging.getLogger("dockerctl")
client = docker.from_env()
disk_mode = C.DISK_MODE if C.DISK_MODE != "auto" else "loop"

PRIVATE_NETS = ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",
                "169.254.0.0/16", "100.64.0.0/10", "127.0.0.0/8")


def _run(cmd):
    return subprocess.run(cmd, check=True, capture_output=True, text=True)


def cname(bot_id):
    return f"hb-{bot_id}"


def mnt(bot_id):
    return C.MNT_DIR / str(bot_id)


def img(bot_id):
    return C.DISKS_DIR / f"{bot_id}.img"


# ---------- диски ----------

def is_mounted(path):
    p = os.path.realpath(path)
    with open("/proc/mounts") as f:
        return any(line.split()[1] == p for line in f)


def _detect_disk_mode():
    global disk_mode
    if C.DISK_MODE != "auto":
        disk_mode = C.DISK_MODE
        return
    t = C.DATA_DIR / "looptest"
    m = C.DATA_DIR / "looptest_mnt"
    shutil.rmtree(t, ignore_errors=True)
    t.mkdir(parents=True)
    m.mkdir(exist_ok=True)
    try:
        with open(t / "t.img", "wb") as f:
            f.truncate(16 * 1024 * 1024)
        _run(["mkfs.ext4", "-q", "-F", str(t / "t.img")])
        _run(["mount", "-o", "loop", str(t / "t.img"), str(m)])
        _run(["umount", str(m)])
        disk_mode = "loop"
    except Exception as e:
        log.warning("loop-монтирование недоступно (%s) -> режим 'du' (мягкий лимит диска)", e)
        disk_mode = "du"
    finally:
        shutil.rmtree(t, ignore_errors=True)
        shutil.rmtree(m, ignore_errors=True)
    log.info("Режим диска: %s", disk_mode)


def ensure_mounted(bot_id):
    m = mnt(bot_id)
    m.mkdir(parents=True, exist_ok=True)
    if disk_mode == "loop" and not is_mounted(m):
        _run(["mount", "-o", "loop,nosuid,nodev", str(img(bot_id)), str(m)])


def create_disk(bot_id, uid):
    m = mnt(bot_id)
    m.mkdir(parents=True, exist_ok=True)
    if disk_mode == "loop":
        with open(img(bot_id), "wb") as f:
            f.truncate(C.DISK_MB * 1024 * 1024)  # sparse-файл
        _run(["mkfs.ext4", "-q", "-F", "-m", "0", str(img(bot_id))])
        _run(["mount", "-o", "loop,nosuid,nodev", str(img(bot_id)), str(m)])
    os.chown(m, uid, uid)
    os.chmod(m, 0o750)


def migrate_uid(bot_id, uid):
    """Разовая миграция старых ботов (uid 1000) на отдельный uid."""
    remove(bot_id)
    ensure_mounted(bot_id)
    _run(["chown", "-R", "-h", f"{uid}:{uid}", str(mnt(bot_id))])  # -h: симлинки не разыменовываются
    os.chmod(mnt(bot_id), 0o750)


def disk_usage(bot_id):
    m = mnt(bot_id)
    if disk_mode == "loop":
        u = shutil.disk_usage(m)
        return u.used, u.total
    r = subprocess.run(["du", "-sb", str(m)], capture_output=True, text=True)
    return int(r.stdout.split()[0]), C.DISK_MB * 1024 * 1024


# ---------- сеть и фаервол ----------

def setup_network():
    try:
        client.networks.get(C.NETWORK)
    except NotFound:
        client.networks.create(
            C.NETWORK, driver="bridge",
            ipam=IPAMConfig(pool_configs=[IPAMPool(subnet=C.SUBNET)]),
            options={"com.docker.network.bridge.enable_icc": "false",   # контейнеры не видят друг друга
                     "com.docker.network.bridge.name": C.BRIDGE})


def _ipt(*args):
    subprocess.run(["iptables", *args], check=True, capture_output=True)


def _ipt_ensure(chain, *rule):
    if subprocess.run(["iptables", "-C", chain, *rule], capture_output=True).returncode != 0:
        _ipt("-I", chain, *rule)


def setup_firewall():
    """Белый список исходящего трафика ботов: DNS + TCP 80/443. Всё остальное, LAN и хост закрыто.
    Цепочка HOSTBOT пересоздаётся при каждом старте менеджера."""
    try:
        subprocess.run(["iptables", "-N", "HOSTBOT"], capture_output=True)  # уже есть - не страшно
        _ipt("-F", "HOSTBOT")
        for net in PRIVATE_NETS:
            _ipt("-A", "HOSTBOT", "-d", net, "-j", "REJECT")
        for dns in C.DNS:
            for proto in ("udp", "tcp"):
                _ipt("-A", "HOSTBOT", "-p", proto, "-d", dns, "--dport", "53", "-j", "ACCEPT")
        # не больше 200 одновременных соединений с одного бота (если модуль есть в ядре)
        subprocess.run(["iptables", "-A", "HOSTBOT", "-p", "tcp", "--syn", "-m", "connlimit",
                        "--connlimit-above", "200", "-j", "REJECT", "--reject-with", "tcp-reset"],
                       capture_output=True)
        _ipt("-A", "HOSTBOT", "-p", "tcp", "-m", "multiport", "--dports", "80,443", "-j", "ACCEPT")
        _ipt("-A", "HOSTBOT", "-j", "REJECT")
        _ipt_ensure("DOCKER-USER", "-i", C.BRIDGE, "-j", "HOSTBOT")
        # сам хост: из контейнеров к нему ходить нельзя
        _ipt_ensure("INPUT", "-i", C.BRIDGE, "-j", "DROP")
        _ipt_ensure("INPUT", "-i", C.BRIDGE, "-m", "conntrack", "--ctstate", "ESTABLISHED,RELATED", "-j", "ACCEPT")
        log.info("Фаервол настроен")
        return True
    except Exception as e:
        log.error("НЕ УДАЛОСЬ настроить iptables: %s", e)
        return False


SELFTEST = """
import socket
def t(h, p):
    s = socket.socket(); s.settimeout(4)
    try:
        s.connect((h, p)); return "OPEN"
    except Exception:
        return "closed"
    finally:
        s.close()
print("https 1.1.1.1:443", t("1.1.1.1", 443))
print("smtp 1.1.1.1:25", t("1.1.1.1", 25))
print("ssh 1.1.1.1:22", t("1.1.1.1", 22))
print("host %(gw)s:22", t("%(gw)s", 22))
print("lan 192.168.0.1:80", t("192.168.0.1", 80))
""" % {"gw": C.GATEWAY}


def selftest():
    """Проверка изнутри контейнера. Возвращает (всё_закрыто_как_надо, отчёт)."""
    try:
        code, out = _oneoff(["python", "-c", SELFTEST], {}, _net(True), C.UID_BASE, 60)
    except Exception as e:
        return False, f"тест не запустился: {e}"
    lines = [l for l in out.splitlines() if l.strip()]
    must_be_closed = [l for l in lines if not l.startswith("https")]
    ok = len(lines) == 5 and all(l.endswith("closed") for l in must_be_closed)
    return ok, "\n".join(lines) or out


def ensure_image():
    try:
        client.images.get(C.IMAGE)
    except NotFound:
        log.info("Собираю базовый образ (пара минут)...")
        client.images.build(path=str(C.SANDBOX_DIR), tag=C.IMAGE, rm=True)


def bootstrap():
    for d in (C.DATA_DIR, C.DISKS_DIR, C.MNT_DIR, C.STAGE_DIR):
        d.mkdir(parents=True, exist_ok=True)
    os.chmod(C.DATA_DIR, 0o700)  # обычные пользователи хоста не видят данные ботов
    _detect_disk_mode()
    setup_network()
    setup_firewall()
    ensure_image()


# ---------- контейнеры ----------

def _limits(uid):
    return dict(
        user=f"{uid}:{uid}", read_only=True,
        tmpfs={"/tmp": "rw,nosuid,size=64m"},
        mem_limit=f"{C.MEM_MB}m", memswap_limit=f"{C.MEM_MB}m",
        nano_cpus=int(C.CPU * 1e9), pids_limit=C.PIDS,
        cap_drop=["ALL"], security_opt=["no-new-privileges"], init=True,
        ulimits=[Ulimit(name="nofile", soft=1024, hard=1024)],
        log_config=LogConfig(type="json-file", config={"max-size": "1m", "max-file": "2"}),
    )


def _env(extra=None):
    e = {"HOME": "/app/home", "USER": "bot", "LOGNAME": "bot", "PYTHONPATH": "/app/.deps",
         "PYTHONUNBUFFERED": "1", "DATA_DIR": "/app/data",
         "PIP_NO_CACHE_DIR": "1", "PIP_DISABLE_PIP_VERSION_CHECK": "1"}
    e.update(extra or {})
    return e


def _net(networked):
    return {"network": C.NETWORK, "dns": C.DNS} if networked else {"network_mode": "none"}


def get(bot_id):
    try:
        return client.containers.get(cname(bot_id))
    except NotFound:
        return None


def remove(bot_id):
    c = get(bot_id)
    if c:
        c.remove(force=True)


def start(bot_id, token, uid):
    ensure_mounted(bot_id)
    remove(bot_id)
    client.containers.run(
        C.IMAGE, ["/entrypoint.sh"], name=cname(bot_id), detach=True, working_dir="/",
        environment=_env({"BOT_TOKEN": token, "TELEGRAM_BOT_TOKEN": token}),
        volumes={str(mnt(bot_id)): {"bind": "/app", "mode": "rw"}},
        **_net(True), **_limits(uid))


def stop(bot_id):
    c = get(bot_id)
    if c and c.status == "running":
        c.stop(timeout=10)


def _ts(s):
    try:
        return datetime.strptime(s[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc).timestamp()
    except Exception:
        return 0


def state(bot_id):
    c = get(bot_id)
    if not c:
        return None
    s = c.attrs["State"]
    return {"status": s["Status"], "exit_code": s.get("ExitCode"),
            "oom": s.get("OOMKilled", False), "started_at": _ts(s.get("StartedAt", ""))}


def logs(bot_id, tail=60):
    c = get(bot_id)
    return c.logs(tail=tail).decode(errors="replace") if c else ""


def stats(bot_id):
    c = get(bot_id)
    s = c.stats(stream=False)
    mem = s["memory_stats"].get("usage", 0)
    st = s["memory_stats"].get("stats", {})
    mem -= st.get("inactive_file", st.get("total_inactive_file", 0))
    cpu_d = s["cpu_stats"]["cpu_usage"]["total_usage"] - s["precpu_stats"]["cpu_usage"]["total_usage"]
    sys_d = s["cpu_stats"].get("system_cpu_usage", 0) - s["precpu_stats"].get("system_cpu_usage", 0)
    ncpu = s["cpu_stats"].get("online_cpus") or 1
    return {"mem": max(mem, 0), "cpu": (cpu_d / sys_d * ncpu * 100) if sys_d > 0 else 0.0}


def _oneoff(cmd, vols, net, uid, timeout):
    c = client.containers.run(C.IMAGE, cmd, detach=True, working_dir="/", volumes=vols,
                              environment=_env(), **net, **_limits(uid))
    try:
        code = c.wait(timeout=timeout)["StatusCode"]
    except Exception:
        c.kill()
        code = 124
    out = c.logs().decode(errors="replace").strip()
    c.remove(force=True)
    return code, out


def run_deploy(bot_id, mode, arg, uid, stage_dir=None, extra=None):
    """Одноразовый контейнер с теми же лимитами. Возвращает (ok, вывод)."""
    ensure_mounted(bot_id)
    vols = {str(mnt(bot_id)): {"bind": "/app", "mode": "rw"}}
    if stage_dir:
        vols[str(stage_dir)] = {"bind": "/in", "mode": "ro"}
    cmd = ["python", "/deploy.py", mode, arg] + ([extra] if extra else [])
    code, out = _oneoff(cmd, vols, _net(mode == "git"), uid, 180)
    return code == 0, out[-1500:] or ("таймаут" if code == 124 else f"код {code}")


def destroy(bot_id):
    remove(bot_id)
    m = mnt(bot_id)
    if disk_mode == "loop" and m.exists() and is_mounted(m):
        r = subprocess.run(["umount", str(m)], capture_output=True)
        if r.returncode:
            subprocess.run(["umount", "-l", str(m)], capture_output=True)
    img(bot_id).unlink(missing_ok=True)
    shutil.rmtree(m, ignore_errors=True)
    shutil.rmtree(C.STAGE_DIR / str(bot_id), ignore_errors=True)

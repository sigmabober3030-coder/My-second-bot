import os
from pathlib import Path


def _int(name, default):
    return int(os.getenv(name, default))


BOT_TOKEN = os.environ["MANAGER_BOT_TOKEN"]
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x}

MAX_BOTS = _int("MAX_BOTS", 20)            # всего слотов на машине
BOTS_PER_USER = _int("BOTS_PER_USER", 1)   # слотов на человека

# Единственный тариф
MEM_MB = _int("BOT_MEM_MB", 256)
CPU = float(os.getenv("BOT_CPUS", "0.25"))
DISK_MB = _int("BOT_DISK_MB", 512)
PIDS = _int("BOT_PIDS", 64)

DATA_DIR = Path(os.getenv("DATA_DIR", "/var/lib/hostbot"))
DB_PATH = DATA_DIR / "hostbot.db"
DISKS_DIR = DATA_DIR / "disks"    # <id>.img (loop-образы)
MNT_DIR = DATA_DIR / "mnt"        # <id>/ (точки монтирования)
STAGE_DIR = DATA_DIR / "stage"    # временные загрузки
SANDBOX_DIR = Path(__file__).parent / "sandbox"

DISK_MODE = os.getenv("DISK_MODE", "auto")  # auto | loop | du

IMAGE = "hostbot-base:latest"
NETWORK = "hostbot_net"
BRIDGE = "hb0"
SUBNET = "172.30.0.0/16"
DNS = ["1.1.1.1", "8.8.8.8"]
UID = 1000

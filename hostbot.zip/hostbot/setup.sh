#!/usr/bin/env bash
set -uo pipefail
[ "$(id -u)" = 0 ] || { echo "Запусти от root: sudo ./setup.sh"; exit 1; }
cd "$(dirname "$0")"

echo "== Проверка окружения =="
command -v docker >/dev/null || { echo "✘ Docker не найден. Установи: curl -fsSL https://get.docker.com | sh"; exit 1; }
docker run --rm hello-world >/dev/null 2>&1 && echo "✔ docker run работает" \
  || { echo "✘ docker run не работает (instabox может быть контейнером без вложенного Docker)"; exit 1; }

if command -v apt-get >/dev/null; then
  apt-get update -qq && apt-get install -y -qq python3-venv python3-pip e2fsprogs iptables >/dev/null
fi

T=$(mktemp -d); mkdir "$T/m"; truncate -s 16M "$T/t.img"
if mkfs.ext4 -q -F "$T/t.img" && mount -o loop "$T/t.img" "$T/m" 2>/dev/null; then
  umount "$T/m"; echo "✔ loop-монтирование работает (жёсткий лимит диска)"
else
  echo "⚠ loop не работает -> менеджер сам перейдёт в режим du (мягкий лимит диска)"
fi
rm -rf "$T"
iptables -L DOCKER-USER >/dev/null 2>&1 && echo "✔ iptables/DOCKER-USER доступны" \
  || echo "⚠ iptables недоступен: изоляция от хоста и LAN будет неполной!"

echo "== Установка =="
D=/opt/hostbot
mkdir -p $D && cp -r main.py config.py db.py dockerctl.py sandbox requirements.txt $D/
python3 -m venv $D/venv && $D/venv/bin/pip install -q -r $D/requirements.txt
docker build -q -t hostbot-base:latest $D/sandbox >/dev/null && echo "✔ базовый образ собран"

if [ ! -f /etc/hostbot.env ]; then
  read -rp "Токен бота-менеджера (от @BotFather): " MT
  read -rp "Твой Telegram ID (админ): " AID
  printf 'MANAGER_BOT_TOKEN=%s\nADMIN_IDS=%s\n' "$MT" "$AID" > /etc/hostbot.env
  chmod 600 /etc/hostbot.env
fi

if [ -d /run/systemd/system ]; then
  cp hostbot.service /etc/systemd/system/ && systemctl daemon-reload && systemctl enable --now hostbot
  echo "✔ Запущено. Логи: journalctl -u hostbot -f"
else
  echo "systemd нет. Запуск вручную:"
  echo "  cd $D && set -a && . /etc/hostbot.env && set +a && ./venv/bin/python main.py"
fi

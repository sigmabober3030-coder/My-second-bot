#!/usr/bin/env python3
"""Проверка связи между двумя ВМ (нужна для обучения на двух машинах сразу).
  На машине A:  python3 nettest.py serve
  На машине B:  python3 nettest.py ping АДРЕС_A
"""
import socket
import subprocess
import sys

PORT = 29500
if len(sys.argv) > 1 and sys.argv[1] == "serve":
    ips = subprocess.run("hostname -I", shell=True, capture_output=True, text=True).stdout.split()
    pub = subprocess.run("curl -s -m 5 ifconfig.me", shell=True, capture_output=True, text=True).stdout.strip()
    print("Адреса этой машины:", ips, "| внешний:", pub or "не определён")
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", PORT))
    s.listen()
    print(f"Жду подключение на порту {PORT}... (Ctrl+C - выход)")
    while True:
        c, a = s.accept()
        print("Подключилась машина:", a)
        c.sendall(b"ok\n")
        c.close()
elif len(sys.argv) > 2 and sys.argv[1] == "ping":
    try:
        c = socket.create_connection((sys.argv[2], PORT), timeout=8)
        print("СВЯЗЬ ЕСТЬ:", c.recv(10).decode().strip())
    except Exception as e:
        print("Связи нет:", e)
else:
    print(__doc__)

#!/usr/bin/env python3
"""Чистка датасета: в категории "Теги сущностей" запросы "Удали у ... метку" и "Добавь тег ..."
в ~47% случаев стоят рядом с противоположной командой (add <-> remove). Скрипт приводит команду
в соответствие с запросом (пояснение там общее, его не трогаем). Ничего не удаляет.

  python clean_dataset.py minecraft_bedrock_1_21_51_10000_commands.jsonl cleaned.jsonl
"""
import json
import sys

src, dst = sys.argv[1], sys.argv[2]
fixed = 0
out = []
for line in open(src, encoding="utf-8"):
    if not line.strip():
        continue
    r = json.loads(line)
    if r["metadata"]["category"] == "Теги сущностей":
        user = r["messages"][0]["content"]
        ans = r["messages"][1]["content"]
        cmd, _, expl = ans.partition("\n\n")
        want = "remove" if user.startswith("Удали у") else "add" if user.startswith("Добавь тег") else None
        have = "remove" if " remove " in cmd else "add" if " add " in cmd else None
        if want and have and want != have:
            cmd = cmd.replace(f" {have} ", f" {want} ", 1)
            r["messages"][1]["content"] = cmd + "\n\n" + expl
            fixed += 1
    out.append(r)

with open(dst, "w", encoding="utf-8") as f:
    for r in out:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")
print(f"Записей: {len(out)}, исправлено: {fixed}")

#!/usr/bin/env python3
"""Готовит смесь для дообучения: все сложные примеры + повтор части простых.

Ответ ассистента = только команды (из блока ```mcfunction```), без пояснений.
Проверочная часть сложных примеров отделяется ПО ШАБЛОНАМ формулировок: так видно, понимает ли модель
незнакомые формулировки. Простые примеры, попавшие в проверку при первом обучении, остаются в проверке.

  python prepare_data.py            (результат: data/mixed.jsonl)
"""
import argparse
import collections
import json
import math
import os
import random
import re

ap = argparse.ArgumentParser()
ap.add_argument("--first", default="data/cleaned.jsonl")
ap.add_argument("--adv", default="data/advanced.jsonl")
ap.add_argument("--old_val", default="runs/main/val.jsonl")
ap.add_argument("--out", default="data/mixed.jsonl")
ap.add_argument("--replay", type=float, default=0.2, help="доля простых примеров, которые повторяем")
ap.add_argument("--adv_val_frac", type=float, default=0.06)
args = ap.parse_args()
rng = random.Random(7)


def read(path):
    return [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]


def norm(s):
    s = re.sub(r"`[^`]*`", "X", s)
    s = re.sub(r"«[^»]*»", "Q", s)
    return re.sub(r"\d+", "N", s)


def code_of(ans):
    blocks = re.findall(r"```[^\n]*\n(.*?)```", ans, re.S)
    return "\n".join(b.strip() for b in blocks).strip()


def mk(user, ans, cat, source, split):
    return {"messages": [{"role": "user", "content": user}, {"role": "assistant", "content": ans}],
            "metadata": {"category": cat, "source": source}, "split": split}


out = []

# ---- сложные примеры: проверка отделяется по шаблонам ----
by_cat = collections.defaultdict(lambda: collections.defaultdict(list))
skipped = 0
fixed_time = 0
for r in read(args.adv):
    user = r["messages"][0]["content"].strip()
    code = code_of(r["messages"][1]["content"])
    if not code:
        skipped += 1
        continue
    # в категории "Мир" 5 примеров с временем в запросе, не совпадающим с /time set в ответе: чиним по запросу
    m = re.search(r"(\d+) тик", user)
    if r["metadata"]["category"].startswith("Мир") and m and re.search(r"/time set \d+", code):
        code = re.sub(r"(/time set )\d+", lambda x: x.group(1) + m.group(1), code, count=1)
        fixed_time += 1
    by_cat[r["metadata"]["category"]][norm(user)].append((user, code))
for cat, stems in by_cat.items():
    n = sum(len(v) for v in stems.values())
    target = math.ceil(n * args.adv_val_frac) if n >= 100 else 0
    keys = list(stems)
    rng.shuffle(keys)
    got, val_keys = 0, set()
    for k in keys:
        if got >= target:
            break
        if got + len(stems[k]) <= 2 * target:
            val_keys.add(k)
            got += len(stems[k])
    for k, items in stems.items():
        for u, c in items:
            out.append(mk(u, c, cat, "adv", "val" if k in val_keys else "train"))

# ---- простые примеры: повтор + прежняя проверка ----
old_users = set()
if os.path.exists(args.old_val):
    for r in read(args.old_val):
        for m in r["messages"]:
            if m["role"] == "user":
                old_users.add(m["content"].strip())
    print(f"Прежняя проверка найдена: {len(old_users)} запросов останутся в проверке")
else:
    print("⚠ Прежней проверки (runs/main/val.jsonl) нет: возьму новую случайную, часть может пересекаться со старым обучением")
byc = collections.defaultdict(list)
for r in read(args.first):
    byc[r["metadata"]["category"]].append((r["messages"][0]["content"].strip(),
                                           r["messages"][1]["content"].split("\n")[0].strip()))
for cat, items in byc.items():
    if old_users:
        val = [x for x in items if x[0] in old_users]
        train = [x for x in items if x[0] not in old_users]
    else:
        rng.shuffle(items)
        k = math.ceil(len(items) * 0.05) if len(items) >= 20 else 0
        val, train = items[:k], items[k:]
    rng.shuffle(train)
    keep = min(len(train), max(15, round(args.replay * len(items))))
    out += [mk(u, c, cat, "first", "train") for u, c in train[:keep]]
    out += [mk(u, c, cat, "first", "val") for u, c in val]

# ---- защита от дыры: команда, почти не встречающаяся в обучении, не должна целиком уходить в проверку ----
def verbs_of(r):
    v = set()
    for l in r["messages"][1]["content"].split("\n"):
        l = l.strip().lstrip("/")
        if l and not l.startswith("#"):
            t = l.split()
            v.add(t[0])
            if t[0] == "execute" and " run " in l:
                v.add("run>" + l.rsplit(" run ", 1)[1].split()[0])
    return v


MIN_TRAIN = 15
train_cnt = collections.Counter(v for r in out if r["split"] == "train" for v in verbs_of(r))
rare = {v for r in out if r["split"] == "val" and r["metadata"]["source"] == "adv"
        for v in verbs_of(r) if train_cnt[v] < MIN_TRAIN}
moved = [r for r in out if r["split"] == "val" and r["metadata"]["source"] == "adv" and verbs_of(r) & rare]
for r in moved:
    r["split"] = "train"
if rare:
    print(f"Редкие команды вернул в обучение: {sorted(rare)} ({len(moved)} примеров)")

# ---- маленький набор для быстрого «доучивания дыр» поверх готовой модели ----
rest = [r for r in out if r["split"] == "train" and r not in moved]
rng.shuffle(rest)
adv_rest = [r for r in rest if r["metadata"]["source"] == "adv"][:250]
first_rest = [r for r in rest if r["metadata"]["source"] == "first"][:150]
fix = [dict(r) for r in moved for _ in range(3)] + adv_rest + first_rest + [r for r in out if r["split"] == "val"]
rng.shuffle(fix)
with open(os.path.join(os.path.dirname(args.out) or ".", "fix.jsonl"), "w", encoding="utf-8") as f:
    for r in fix:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

rng.shuffle(out)
with open(args.out, "w", encoding="utf-8") as f:
    for r in out:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

cnt = collections.Counter((r["metadata"]["source"], r["split"]) for r in out)
print(f"Записано {len(out)} примеров в {args.out} (без блока кода пропущено: {skipped}, время исправлено: {fixed_time})")
print(f"Для быстрого доучивания: data/fix.jsonl ({sum(1 for r in fix if r['split'] != 'val')} примеров на обучение)")
for (s, sp), n in sorted(cnt.items()):
    print(f"  {'сложные' if s == 'adv' else 'простые'} / {'проверка' if sp == 'val' else 'обучение'}: {n}")

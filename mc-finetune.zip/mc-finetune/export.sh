#!/usr/bin/env bash
# Экспорт обученной модели в файлы. Положи рядом с run.sh (в папку mc-finetune).
cd "$(dirname "$0")"
PY=./venv/bin/python
[ -x "$PY" ] || { echo "Сначала ./run.sh setup"; exit 1; }

pick() {
  for r in runs/q35 runs/v21 runs/v2 runs/main; do [ -d $r/adapter ] && { RUN=$r; case $r in runs/q35) PY=./venv35/bin/python;; esac; return; }; done
  echo "Обученной модели не найдено (runs/*/adapter)"; exit 1
}

case "${1:-help}" in
merge)
  pick
  echo "Беру модель из $RUN"
  $PY export_model.py --run $RUN --out export
  du -sh export/adapter export/merged
  echo "Дальше: ./export.sh gguf  (один файл для Ollama / LM Studio)"
  ;;
gguf)
  [ -d export/merged ] || { echo "Сначала: ./export.sh merge"; exit 1; }
  [ -d llama.cpp ] || git clone --depth 1 https://github.com/ggml-org/llama.cpp || exit 1
  ./venv/bin/pip install -q numpy pyyaml tqdm sentencepiece protobuf
  $PY llama.cpp/convert_hf_to_gguf.py export/merged --outfile export/mc-bedrock-q8_0.gguf --outtype q8_0 || exit 1
  ls -lh export/*.gguf
  echo "Для Ollama:  cd export && ollama create mc-bedrock -f Modelfile && ollama run mc-bedrock"
  ;;
*)
  cat <<'HELP'
  ./export.sh merge   слить адаптер с моделью (папка export/: adapter 35 МБ, merged ~1 ГБ)
  ./export.sh gguf    сделать один файл export/mc-bedrock-q8_0.gguf (~0.5 ГБ)
HELP
  ;;
esac

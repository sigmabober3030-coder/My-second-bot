#!/usr/bin/env python3
"""Подготовка новых данных (recommended_4500 + golden).
- ответ = только команды (из блока кода или первого абзаца); тексты отказов остаются текстом
- диалоги разворачиваются: каждая реплика ассистента становится отдельным примером
- проверка отделяется ПО ШАБЛОНАМ (template_id); запросы из golden удаляются из обучения
- добавляется повтор старых данных (иначе модель забудет fill/setblock/scoreboard и т.д.)

  python prepare_new.py [--replay 2500]   -> data/new_train.jsonl, data/gold_eval.jsonl
"""
import argparse
import collections
import json
import math
import os
import random
import re

ap = argparse.ArgumentParser()
ap.add_argument("--src", default="data/rec4500.jsonl")
ap.add_argument("--golden", default="data/golden.jsonl")
ap.add_argument("--mixed", default="data/mixed.jsonl", help="старая смесь из ./run.sh prepare")
ap.add_argument("--replay", type=int, default=2500)
ap.add_argument("--val_frac", type=float, default=0.06)
ap.add_argument("--out", default="data/new_train.jsonl")
ap.add_argument("--gold_out", default="data/gold_eval.jsonl")
args = ap.parse_args()
rng = random.Random(11)


def read(p):
    return [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]


def clean(ans):
    f = re.findall(r"```[^\n]*\n(.*?)```", ans, re.S)
    if f:
        return "\n".join(x.strip() for x in f).strip()
    a = ans.strip()
    return a.split("\n\n")[0].strip() if a.startswith("/") else a


def convs(r, last_only=False):
    m = r["messages"]
    ks = [len(m) - 1] if last_only else range(1, len(m), 2)
    return [[{"role": x["role"], "content": clean(x["content"]) if x["role"] == "assistant" else x["content"].strip()}
             for x in m[:k + 1]] for k in ks]


def row(conv, cat, src, tpl, split):
    return {"messages": conv, "metadata": {"category": cat, "source": src, "template_id": tpl}, "split": split}


# ---- golden: итоговая проверка, одна реплика (последняя) на пример ----
gold = read(args.golden)
gold_users = {x["content"].strip() for r in gold for x in r["messages"] if x["role"] == "user"}
with open(args.gold_out, "w", encoding="utf-8") as f:
    for r in gold:
        for c in convs(r, last_only=True):
            f.write(json.dumps(row(c, r["metadata"]["category"], "gold", r["metadata"]["template_id"], "gold"),
                               ensure_ascii=False) + "\n")

# ---- новые данные ----
by_cat = collections.defaultdict(lambda: collections.defaultdict(list))
leaked = 0
for r in read(args.src):
    for c in convs(r):
        if any(x["role"] == "user" and x["content"] in gold_users for x in c):
            leaked += 1
            continue
        by_cat[r["metadata"]["category"]][r["metadata"]["template_id"]].append(c)
out = []
for cat, tpls in by_cat.items():
    n = sum(len(v) for v in tpls.values())
    target = math.ceil(n * args.val_frac) if len(tpls) >= 6 else 0
    keys = list(tpls)
    rng.shuffle(keys)
    got, vk = 0, set()
    for k in keys:
        if got >= target:
            break
        if got + len(tpls[k]) <= 2 * target:
            vk.add(k)
            got += len(tpls[k])
    for k, cs in tpls.items():
        out += [row(c, cat, "new", k, "val" if k in vk else "train") for c in cs]

# ---- повтор старых данных ----
replay = 0
if args.replay and os.path.exists(args.mixed):
    old = read(args.mixed)

    def pick(rows, n):
        g = collections.defaultdict(list)
        for r in rows:
            g[r["metadata"]["category"]].append(r)
        for v in g.values():
            rng.shuffle(v)
        res = []
        while len(res) < n and any(g.values()):
            for k in sorted(g):
                if g[k] and len(res) < n:
                    res.append(g[k].pop())
        return res
    for r in pick([x for x in old if x["split"] == "train"], args.replay) + \
            pick([x for x in old if x["split"] == "val"], 200):
        out.append(row(r["messages"], r["metadata"]["category"], "old", "", r["split"]))
        replay += 1
elif args.replay:
    print("⚠ Старой смеси нет (data/mixed.jsonl): сначала ./run.sh prepare. Продолжаю без повтора.")

rng.shuffle(out)
with open(args.out, "w", encoding="utf-8") as f:
    for r in out:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

c = collections.Counter((r["metadata"]["source"], r["split"]) for r in out)
tok = sum(sum(len(m["content"]) for m in r["messages"]) + 60 for r in out if r["split"] == "train") / 2.02
print(f"Обучение: {sum(v for (s, sp), v in c.items() if sp == 'train')} (новых {c[('new', 'train')]}, повтор старых {c[('old', 'train')]}), "
      f"проверка: {sum(v for (s, sp), v in c.items() if sp == 'val')}; убрано из-за golden: {leaked}")
print(f"Оценка: ~{tok / 1e3:.0f} тыс. токенов за проход; golden для финальной оценки: {args.gold_out}")

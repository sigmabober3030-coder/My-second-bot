#!/usr/bin/env bash
# Простой запуск дообучения. Все команды: ./run.sh  (без аргументов покажет подсказку)
cd "$(dirname "$0")"
PY=./venv/bin/python
DATA=data/cleaned.jsonl
export TOKENIZERS_PARALLELISM=false HF_HUB_DISABLE_TELEMETRY=1 OMP_NUM_THREADS="$(nproc)"
SUDO=""; [ "$(id -u)" != 0 ] && command -v sudo >/dev/null && SUDO=sudo

need_venv() { [ -x "$PY" ] || { echo "Сначала выполни: ./run.sh setup"; exit 1; }; }
pick_run() { if [ -d runs/main/adapter ]; then RUN=runs/main; elif [ -d runs/test/adapter ]; then RUN=runs/test; else echo "Модели ещё нет. Запусти ./run.sh test или ./run.sh train"; exit 1; fi; }
running() { pgrep -f "^\./venv/bin/python train_lora\.py" >/dev/null; }

case "${1:-help}" in
setup)
  echo "== Проверка машины =="
  echo "Ядер: $(nproc)"; free -m | sed -n 2p; df -h . | tail -1
  if command -v apt-get >/dev/null; then
    $SUDO apt-get update -qq && $SUDO apt-get install -y -qq python3-venv python3-pip tmux >/dev/null
  fi
  echo "== Устанавливаю библиотеки (несколько минут) =="
  python3 -m venv venv && ./venv/bin/pip install -q --upgrade pip
  ./venv/bin/pip install -q torch --index-url https://download.pytorch.org/whl/cpu
  ./venv/bin/pip install -q transformers peft
  $PY -c "import torch, transformers, peft; print('Готово. torch', torch.__version__)"
  echo "Дальше: ./run.sh test"
  ;;

test)
  need_venv
  echo "== Быстрая проверка на 200 примерах (пара минут + загрузка модели) =="
  $PY train_lora.py --data $DATA --out runs/test --limit 200 2>&1 | grep -v -i warn
  echo
  echo "Смотри строки 'ток/с' и 'осталось' выше. Для полного обучения скорость примерно такая же."
  echo "Если всё ок: ./run.sh train"
  ;;

train)
  need_venv
  if running; then echo "Обучение уже идёт. Смотри: ./run.sh status"; exit 0; fi
  FREE=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  if [ "$FREE" -lt 4000 ] && [ -z "$FORCE" ]; then
    echo "⚠ Свободно только ${FREE} МБ памяти, нужно хотя бы 4000."
    echo "Останови лишнее: sudo systemctl stop hostbot && docker stop \$(docker ps -q)"
    echo "(или запусти с FORCE=1, если уверен)"; exit 1
  fi
  RUN=runs/main; mkdir -p $RUN
  RESUME=""; [ -d $RUN/adapter ] && RESUME="--resume" && echo "Нашёл прошлый прогресс, продолжаю с него."
  cat > $RUN/job.sh <<JOB
#!/usr/bin/env bash
cd "$(pwd)"
$PY train_lora.py --data $DATA --out $RUN --epochs ${2:-1} $RESUME 2>&1 | grep --line-buffered -v -i warn | tee -a $RUN/train.log
JOB
  if command -v tmux >/dev/null; then
    tmux new-session -d -s mc "bash $PWD/$RUN/job.sh"
  else
    nohup bash $RUN/job.sh >/dev/null 2>&1 &
  fi
  echo "🚀 Обучение запущено в фоне. Можно закрывать терминал."
  echo "Как дела: ./run.sh status    Остановить: ./run.sh stop"
  ;;

status)
  if running; then echo "🟢 Обучение идёт"; else echo "⚪ Обучение сейчас не идёт"; fi
  LOG=runs/main/train.log
  if [ -f $LOG ]; then
    LAST=$(grep -o 'шаг [0-9]*/[0-9]*' $LOG | tail -1)
    [ -n "$LAST" ] && echo "Прогресс: $LAST ($(echo "$LAST" | awk -F'[ /]' '{printf "%d%%", $2*100/$3}'))"
    echo "--- последние строки лога ---"; tail -n 4 $LOG
  fi
  echo "--- память ---"; free -m | sed -n '1,2p'
  ;;

stop)
  tmux kill-session -t mc 2>/dev/null; pkill -f "^\./venv/bin/python train_lora\.py" && echo "Остановлено. Прогресс сохраняется каждые 25 шагов; продолжить: ./run.sh train" || echo "Ничего не запущено."
  ;;

eval)
  need_venv; pick_run
  echo "Проверяю модель из $RUN на ${2:-100} отложенных примерах (это не быстро)..."
  $PY eval_cmd.py --out $RUN --n "${2:-100}"
  ;;

eval-base)
  need_venv; pick_run
  echo "Проверяю ИСХОДНУЮ модель (без дообучения) для сравнения..."
  $PY eval_cmd.py --out $RUN --n "${2:-100}" --no_adapter
  ;;

ask)
  need_venv; pick_run; shift
  [ -z "$*" ] && { echo 'Пример: ./run.sh ask "Поставь блок stone на 0 64 0"'; exit 1; }
  $PY eval_cmd.py --out $RUN --ask "$*"
  ;;

chat)
  need_venv; pick_run
  $PY eval_cmd.py --out $RUN --chat
  ;;

*)
  cat <<'HELP'
Дообучение Qwen2.5-Coder-0.5B на командах Minecraft Bedrock 1.21.51

  ./run.sh setup        1. один раз: установить всё нужное
  ./run.sh test         2. быстрая проверка (несколько минут)
  ./run.sh train        3. полное обучение в фоне  (./run.sh train 2 = две эпохи)
  ./run.sh status       как идёт обучение
  ./run.sh stop         остановить (прогресс сохранится)
  ./run.sh eval         оценить модель на отложенных примерах
  ./run.sh eval-base    то же для исходной модели (чтобы сравнить)
  ./run.sh ask "..."    задать один вопрос модели
  ./run.sh chat         общаться с моделью в терминале
HELP
  ;;
esac

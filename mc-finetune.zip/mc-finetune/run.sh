#!/usr/bin/env bash
# Простой запуск дообучения. Все команды: ./run.sh  (без аргументов покажет подсказку)
cd "$(dirname "$0")"
PY=./venv/bin/python
DATA=data/cleaned.jsonl
export TOKENIZERS_PARALLELISM=false HF_HUB_DISABLE_TELEMETRY=1 OMP_NUM_THREADS="$(nproc)"
SUDO=""; [ "$(id -u)" != 0 ] && command -v sudo >/dev/null && SUDO=sudo

need_venv() { [ -x "$PY" ] || { echo "Сначала выполни: ./run.sh setup"; exit 1; }; }
pick_run() {
  if [ -z "$RUN" ] || [ ! -d "$RUN/adapter" ]; then
    RUN=$(ls -dt runs/*/adapter 2>/dev/null | grep -v '/test' | head -1 | sed 's|/adapter$||')
    [ -z "$RUN" ] && RUN=$(ls -dt runs/*/adapter 2>/dev/null | head -1 | sed 's|/adapter$||')
    [ -z "$RUN" ] && { echo "Модели ещё нет. Запусти ./run.sh test или ./run.sh train"; exit 1; }
  fi
  case "$RUN" in runs/q35*) PY=./venv35/bin/python;; esac
  [ -x "$PY" ] || { echo "Нет окружения для $RUN ($PY). Для Qwen3.5: ./run.sh setup35"; exit 1; }
}
SYS_V1="Minecraft Bedrock 1.21.51. Ответь одной командой."
SYS_V2="Minecraft Bedrock 1.21.51. Отвечай только командами."
SYS_V3="Minecraft Bedrock 1.21.51. Отвечай командами; если задача невыполнима в Bedrock, коротко объясни."
Q35_ARGS="--model Qwen/Qwen3.5-2B --dtype bf16 --grad_ckpt --targets all-linear --no_think --manual_target --no-only_command --max_len 384 --lr 1e-4"
running() { pgrep -f "^\./venv(35)?/bin/python train_lora\.py" >/dev/null; }

case "${1:-help}" in
setup)
  echo "== Проверка машины =="
  echo "Ядер: $(nproc)"; free -m | sed -n 2p; df -h . | tail -1
  if command -v apt-get >/dev/null; then
    $SUDO apt-get update -qq && $SUDO apt-get install -y -qq python3-venv python3-pip tmux >/dev/null
  fi
  echo "== Устанавливаю библиотеки (несколько минут) =="
  python3 -m venv venv && ./venv/bin/pip install -q --upgrade pip
  ./venv/bin/pip install -q torch --index-url https://download.pytorch.org/whl/cpu
  ./venv/bin/pip install -q transformers peft
  $PY -c "import torch, transformers, peft; print('Готово. torch', torch.__version__)"
  echo "Дальше: ./run.sh test"
  ;;

test)
  need_venv
  echo "== Быстрая проверка на 200 примерах (пара минут + загрузка модели) =="
  $PY train_lora.py --data $DATA --out runs/test --limit 200 --system "$SYS_V1" 2>&1 | grep -v -i warn
  echo
  echo "Смотри строки 'ток/с' и 'осталось' выше. Для полного обучения скорость примерно такая же."
  echo "Если всё ок: ./run.sh train"
  ;;

train)
  need_venv
  if running; then echo "Обучение уже идёт. Смотри: ./run.sh status"; exit 0; fi
  FREE=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  if [ "$FREE" -lt 4000 ] && [ -z "$FORCE" ]; then
    echo "⚠ Свободно только ${FREE} МБ памяти, нужно хотя бы 4000."
    echo "Останови лишнее: sudo systemctl stop hostbot && docker stop \$(docker ps -q)"
    echo "(или запусти с FORCE=1, если уверен)"; exit 1
  fi
  RUN=runs/main; mkdir -p $RUN
  RESUME=""; [ -d $RUN/adapter ] && RESUME="--resume" && echo "Нашёл прошлый прогресс, продолжаю с него."
  cat > $RUN/job.sh <<JOB
#!/usr/bin/env bash
cd "$(pwd)"
$PY train_lora.py --data $DATA --out $RUN --epochs ${2:-1} --system "$SYS_V1" $RESUME 2>&1 | grep --line-buffered -v -i warn | tee -a $RUN/train.log
JOB
  if command -v tmux >/dev/null; then
    tmux new-session -d -s mc "bash $PWD/$RUN/job.sh"
  else
    nohup bash $RUN/job.sh >/dev/null 2>&1 &
  fi
  echo "🚀 Обучение запущено в фоне. Можно закрывать терминал."
  echo "Как дела: ./run.sh status    Остановить: ./run.sh stop"
  ;;

prepare)
  python3 prepare_data.py
  echo "Дальше: ./run.sh train2"
  ;;

train2)
  need_venv
  [ -f data/mixed.jsonl ] || { echo "Сначала выполни: ./run.sh prepare"; exit 1; }
  if running; then echo "Обучение уже идёт. Смотри: ./run.sh status"; exit 0; fi
  FREE=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  if [ "$FREE" -lt 4000 ] && [ -z "$FORCE" ]; then
    echo "⚠ Свободно только ${FREE} МБ памяти, нужно хотя бы 4000."
    echo "Останови лишнее: sudo systemctl stop hostbot && docker stop \$(docker ps -q)"; exit 1
  fi
  RUN=runs/v2; mkdir -p $RUN
  RESUME=""; INIT=""
  if [ -d $RUN/adapter ]; then RESUME="--resume"; echo "Нашёл прошлый прогресс, продолжаю с него."
  elif [ -d runs/main/adapter ]; then INIT="--init_adapter runs/main/adapter"; echo "Стартую с уже обученной модели (runs/main)."
  else echo "Прежней модели нет, обучаю с нуля."; fi
  cat > $RUN/job.sh <<JOB
#!/usr/bin/env bash
cd "$(pwd)"
$PY train_lora.py --data data/mixed.jsonl --out $RUN --epochs ${2:-1} --max_len 384 --lr 1e-4 --no-only_command --system "$SYS_V2" $INIT $RESUME 2>&1 | grep --line-buffered -v -i warn | tee -a $RUN/train.log
JOB
  if command -v tmux >/dev/null; then
    tmux new-session -d -s mc "bash $PWD/$RUN/job.sh"
  else
    nohup bash $RUN/job.sh >/dev/null 2>&1 &
  fi
  echo "🚀 Обучение v2 запущено в фоне (примерно 4 часа). Можно закрывать терминал."
  echo "Как дела: ./run.sh status    Остановить: ./run.sh stop"
  ;;

fix)
  need_venv
  [ -f data/fix.jsonl ] || { echo "Сначала выполни: ./run.sh prepare"; exit 1; }
  [ -d runs/v2/adapter ] || { echo "Нужна готовая модель runs/v2"; exit 1; }
  if running; then echo "Обучение уже идёт. Смотри: ./run.sh status"; exit 0; fi
  FREE=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  if [ "$FREE" -lt 4000 ] && [ -z "$FORCE" ]; then
    echo "⚠ Свободно только ${FREE} МБ памяти, нужно хотя бы 4000."; exit 1
  fi
  RUN=runs/v21; mkdir -p $RUN
  RESUME=""; INIT=""
  if [ -d $RUN/adapter ]; then RESUME="--resume"; echo "Нашёл прошлый прогресс, продолжаю."; else INIT="--init_adapter runs/v2/adapter"; echo "Стартую с модели v2."; fi
  cat > $RUN/job.sh <<JOB
#!/usr/bin/env bash
cd "$(pwd)"
$PY train_lora.py --data data/fix.jsonl --out $RUN --epochs 1 --max_len 384 --lr 5e-5 --no-only_command --system "$SYS_V2" $INIT $RESUME 2>&1 | grep --line-buffered -v -i warn | tee -a $RUN/train.log
JOB
  if command -v tmux >/dev/null; then
    tmux new-session -d -s mc "bash $PWD/$RUN/job.sh"
  else
    nohup bash $RUN/job.sh >/dev/null 2>&1 &
  fi
  echo "🚀 Быстрое доучивание запущено (около 15-30 минут). Смотри: ./run.sh status"
  ;;

setup35)
  echo "== Отдельное окружение для Qwen3.5 (старое не трогаю) =="
  python3 -m venv venv35 && ./venv35/bin/pip install -q --upgrade pip
  ./venv35/bin/pip install -q torch --index-url https://download.pytorch.org/whl/cpu
  ./venv35/bin/pip install -q -U transformers peft accelerate pillow
  ./venv35/bin/python -c "import torch, transformers, peft; print('torch', torch.__version__, '| transformers', transformers.__version__, '| peft', peft.__version__)"
  echo "Если дальше будет ошибка про неизвестную архитектуру qwen3_5, поставь свежий transformers:"
  echo "  ./venv35/bin/pip install -U 'git+https://github.com/huggingface/transformers.git'"
  echo "Дальше: ./run.sh test35"
  ;;

test35)
  [ -x ./venv35/bin/python ] || { echo "Сначала выполни: ./run.sh setup35"; exit 1; }
  [ -f data/mixed.jsonl ] || { echo "Сначала выполни: ./run.sh prepare"; exit 1; }
  if running; then echo "Обучение уже идёт: ./run.sh stop"; exit 1; fi
  echo "== Проверка Qwen3.5-2B: 6 шагов (первый раз качается модель ~4-5 ГБ) =="
  mkdir -p runs/test35
  ./venv35/bin/python train_lora.py --data data/mixed.jsonl --out runs/test35 $Q35_ARGS --system "$SYS_V2" \
    --limit 48 --accum 8 --val_n 12 --log_every 1 2>&1 | grep --line-buffered -v -i warn | tee runs/test35/test.log
  T=$(grep -o '[0-9.]* ток/с' runs/test35/test.log | tail -1 | awk '{print $1}')
  M=$(grep -o 'память до [0-9]*' runs/test35/test.log | tail -1 | awk '{print $3}')
  if [ -n "$T" ]; then
    echo
    echo "Скорость: $T ток/с, пик памяти: ${M:-?} МБ (на машине всего $(free -m | awk '/Mem:/ {print $2}') МБ)"
    awk -v t="$T" 'BEGIN { printf "Оценка: одна эпоха (~1 млн токенов) = около %.0f ч; 0.4 эпохи = около %.0f ч\n", 1000000/t/3600, 400000/t/3600 }'
  else
    echo "Не удалось получить скорость: пришли вывод выше."
  fi
  ;;

train35)
  [ -x ./venv35/bin/python ] || { echo "Сначала выполни: ./run.sh setup35"; exit 1; }
  [ -f data/mixed.jsonl ] || { echo "Сначала выполни: ./run.sh prepare"; exit 1; }
  if running; then echo "Обучение уже идёт. Смотри: ./run.sh status"; exit 0; fi
  FREE=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  if [ "$FREE" -lt 5500 ] && [ -z "$FORCE" ]; then
    echo "⚠ Свободно только ${FREE} МБ памяти, для 2B нужно хотя бы 5500."
    echo "Останови лишнее: sudo systemctl stop hostbot && docker stop \$(docker ps -q)"; exit 1
  fi
  RUN=runs/q35; mkdir -p $RUN
  RESUME=""; [ -d $RUN/adapter ] && RESUME="--resume" && echo "Нашёл прошлый прогресс, продолжаю."
  cat > $RUN/job.sh <<JOB
#!/usr/bin/env bash
cd "$(pwd)"
./venv35/bin/python train_lora.py --data data/mixed.jsonl --out $RUN --epochs ${2:-1} $Q35_ARGS --system "$SYS_V2" --save_every 10 --val_n 60 $RESUME 2>&1 | grep --line-buffered -v -i warn | tee -a $RUN/train.log
JOB
  if command -v tmux >/dev/null; then
    tmux new-session -d -s mc "bash $PWD/$RUN/job.sh"
  else
    nohup bash $RUN/job.sh >/dev/null 2>&1 &
  fi
  echo "🚀 Qwen3.5-2B запущена в фоне. Смотри: ./run.sh status   Остановить: ./run.sh stop"
  ;;

prepare-new)
  [ -f data/mixed.jsonl ] || ./run.sh prepare
  python3 prepare_new.py --replay "${2:-2500}"
  echo "Дальше: ./run.sh new05  (быстро, 0.5B)   или   ./run.sh new2b  (Qwen3.5-2B)"
  ;;

new05|new2b)
  [ -f data/new_train.jsonl ] || { echo "Сначала: ./run.sh prepare-new"; exit 1; }
  if running; then echo "Обучение уже идёт: ./run.sh status"; exit 0; fi
  FREE=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  MIN=4000; [ "$1" = new2b ] && MIN=5500
  if [ "$FREE" -lt "$MIN" ] && [ -z "$FORCE" ]; then
    echo "⚠ Свободно ${FREE} МБ, нужно ${MIN}. Останови лишнее: sudo systemctl stop hostbot && docker stop \$(docker ps -q)"; exit 1
  fi
  ENVX=""
  if [ "$1" = new05 ]; then
    [ -x ./venv/bin/python ] || { echo "Сначала: ./run.sh setup"; exit 1; }
    RUN=runs/n05; PYB=./venv/bin/python; INIT=""
    for p in runs/v21 runs/v2 runs/main; do [ -d $p/adapter ] && { INIT="--init_adapter $p/adapter"; break; }; done
    ARGS="--model Qwen/Qwen2.5-Coder-0.5B-Instruct --max_len 384 --lr 1e-4 --no-only_command --save_every 25 $INIT"
  else
    [ -x ./venv35/bin/python ] || { echo "Сначала: ./run.sh setup35"; exit 1; }
    RUN=runs/q35n; PYB=./venv35/bin/python
    ARGS="$Q35_ARGS --save_every 10 --val_n 60"
    # две машины: DIST_ADDR=адрес_главной DIST_RANK=0|1 ./run.sh new2b
    [ -n "$DIST_ADDR" ] && ENVX="export MASTER_ADDR=$DIST_ADDR MASTER_PORT=29500 WORLD_SIZE=2 RANK=${DIST_RANK:-0}"
  fi
  mkdir -p $RUN
  RESUME=""; [ -d $RUN/adapter ] && RESUME="--resume" && echo "Нашёл прошлый прогресс, продолжаю."
  cat > $RUN/job.sh <<JOB
#!/usr/bin/env bash
cd "$(pwd)"
$ENVX
$PYB train_lora.py --data data/new_train.jsonl --out $RUN --epochs ${2:-1} $ARGS --system "$SYS_V3" $RESUME 2>&1 | grep --line-buffered -v -i warn | tee -a $RUN/train.log
JOB
  if command -v tmux >/dev/null; then tmux new-session -d -s mc "bash $PWD/$RUN/job.sh"; else nohup bash $RUN/job.sh >/dev/null 2>&1 & fi
  echo "🚀 Запущено ($1). Смотри: ./run.sh status   Остановить: ./run.sh stop"
  ;;

eval-gold)
  pick_run
  [ -f data/gold_eval.jsonl ] || { echo "Сначала: ./run.sh prepare-new"; exit 1; }
  echo "Оцениваю $RUN на golden-наборе (${2:-120} примеров)..."
  $PY eval_cmd.py --out $RUN --file data/gold_eval.jsonl --n "${2:-120}"
  ;;

nettest)
  python3 nettest.py "$2" "$3"
  ;;

status)
  if running; then echo "🟢 Обучение идёт"; else echo "⚪ Обучение сейчас не идёт"; fi
  LOG=$(ls -t runs/*/train.log 2>/dev/null | head -1)
  if [ -n "$LOG" ] && [ -f "$LOG" ]; then
    echo "Лог: $LOG"
    LAST=$(grep -o 'шаг [0-9]*/[0-9]*' $LOG | tail -1)
    [ -n "$LAST" ] && echo "Прогресс: $LAST ($(echo "$LAST" | awk -F'[ /]' '{printf "%d%%", $2*100/$3}'))"
    echo "--- последние строки лога ---"; tail -n 4 $LOG
  fi
  echo "--- память ---"; free -m | sed -n '1,2p'
  ;;

stop)
  tmux kill-session -t mc 2>/dev/null; pkill -f "^\./venv(35)?/bin/python train_lora\.py" && echo "Остановлено. Прогресс сохраняется каждые 25 шагов; продолжить: ./run.sh train" || echo "Ничего не запущено."
  ;;

eval)
  pick_run
  echo "Проверяю модель из $RUN на ${2:-60} отложенных примерах (это не быстро)..."
  $PY eval_cmd.py --out $RUN --n "${2:-60}"
  ;;

eval-base)
  pick_run
  echo "Проверяю ИСХОДНУЮ модель (без дообучения) для сравнения..."
  $PY eval_cmd.py --out $RUN --n "${2:-60}" --no_adapter
  ;;

ask)
  pick_run; shift
  [ -z "$*" ] && { echo 'Пример: ./run.sh ask "Поставь блок stone на 0 64 0"'; exit 1; }
  $PY eval_cmd.py --out $RUN --ask "$*"
  ;;

chat)
  pick_run
  $PY eval_cmd.py --out $RUN --chat
  ;;

*)
  cat <<'HELP'
Дообучение Qwen2.5-Coder-0.5B на командах Minecraft Bedrock 1.21.51

  ./run.sh setup        1. один раз: установить всё нужное
  ./run.sh test         2. быстрая проверка (несколько минут)
  ./run.sh train        3. полное обучение в фоне  (./run.sh train 2 = две эпохи)
  ./run.sh prepare      4. собрать смесь простых и сложных данных (для v2)
  ./run.sh train2       5. дообучить на смеси, ~4 часа (v2)
  ./run.sh fix          6. быстро доучить редкие команды поверх v2 (~20 минут)
  ./run.sh setup35      7. окружение для Qwen3.5-2B (один раз)
  ./run.sh test35       8. проверка Qwen3.5-2B: скорость и память (~15 минут)
  ./run.sh train35      9. обучение Qwen3.5-2B в фоне (./run.sh train35 0.4 = 40% эпохи)
  ./run.sh prepare-new  10. подготовить новые данные (recommended_4500 + повтор старых)
  ./run.sh new05        11. 0.5B: доучить на новых данных (~3 ч)
  ./run.sh new2b        12. Qwen3.5-2B на новых данных (одна или две машины)
  ./run.sh eval-gold    оценка по golden-набору (диалоги и отказы тоже)
  ./run.sh nettest serve | ping АДРЕС   проверка связи между двумя ВМ
  ./run.sh status       как идёт обучение
  ./run.sh stop         остановить (прогресс сохранится)
  ./run.sh eval         оценить модель на отложенных примерах
  ./run.sh eval-base    то же для исходной модели (чтобы сравнить)
  ./run.sh ask "..."    задать один вопрос модели
  ./run.sh chat         общаться с моделью в терминале
HELP
  ;;
esac

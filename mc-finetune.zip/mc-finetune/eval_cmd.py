#!/usr/bin/env python3
"""Проверка модели на отложенных примерах: точное совпадение команды.

  python eval_cmd.py --out out              # с обученным адаптером
  python eval_cmd.py --out out --no_adapter # базовая модель (для сравнения)
  python eval_cmd.py --out out --ask "Поставь блок stone на 0 64 0"   # один запрос
"""
import argparse
import json
import os
from collections import defaultdict

import torch
import transformers
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

ap = argparse.ArgumentParser()
ap.add_argument("--out", default="out")
ap.add_argument("--n", type=int, default=200)
ap.add_argument("--no_adapter", action="store_true")
ap.add_argument("--ask", default="")
ap.add_argument("--chat", action="store_true", help="интерактивный режим")
args = ap.parse_args()
transformers.logging.set_verbosity_error()

meta = json.load(open(os.path.join(args.out, "meta.json"), encoding="utf-8"))
tok = AutoTokenizer.from_pretrained(meta["model"])
model = AutoModelForCausalLM.from_pretrained(meta["model"], torch_dtype=torch.float32)
if not args.no_adapter:
    model = PeftModel.from_pretrained(model, os.path.join(args.out, "adapter")).merge_and_unload()
model.eval()


def ask(user):
    msgs = ([{"role": "system", "content": meta["system"]}] if meta["system"] else []) + \
           [{"role": "user", "content": user}]
    text = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
    x = tok(text, return_tensors="pt", add_special_tokens=False)
    with torch.no_grad():
        y = model.generate(**x, max_new_tokens=80, do_sample=False)
    return tok.decode(y[0][x["input_ids"].shape[1]:], skip_special_tokens=True).strip().split("\n")[0].strip()


if args.ask:
    print(ask(args.ask))
    raise SystemExit

if args.chat:
    print("Готово! Пиши задачу по-русски, например: Поставь блок stone на координаты 0 64 0")
    print("Пустая строка или Ctrl+D - выход.\n")
    while True:
        try:
            q = input("Ты: ").strip()
        except EOFError:
            break
        if not q:
            break
        print("Модель:", ask(q), "\n")
    raise SystemExit

rows = [json.loads(l) for l in open(os.path.join(args.out, "val.jsonl"), encoding="utf-8")][: args.n]
ok = verb_ok = 0
per = defaultdict(lambda: [0, 0])
misses = []
for r in rows:
    user = [m for m in r["messages"] if m["role"] == "user"][0]["content"]
    ref = r["messages"][-1]["content"].strip().split("\n")[0].strip()
    got = ask(user)
    hit = " ".join(got.split()) == " ".join(ref.split())
    ok += hit
    verb_ok += got.split()[:1] == ref.split()[:1]
    per[r["category"]][0] += hit
    per[r["category"]][1] += 1
    if not hit and len(misses) < 12:
        misses.append((user, ref, got))
n = len(rows)
print(f"\nТочное совпадение: {ok}/{n} = {100 * ok / n:.1f}%   Верная команда-глагол: {100 * verb_ok / n:.1f}%")
for c, (a, b) in sorted(per.items(), key=lambda kv: -kv[1][1]):
    print(f"  {a}/{b}  {c}")
print("\nПримеры ошибок:")
for u, ref, got in misses:
    print(f"- {u}\n    надо: {ref}\n    модель: {got}")

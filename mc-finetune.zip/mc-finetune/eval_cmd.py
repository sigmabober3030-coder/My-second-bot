#!/usr/bin/env python3
"""Проверка модели на отложенных примерах (команды могут быть многострочными).

  python eval_cmd.py --out runs/v2              # с обученным адаптером
  python eval_cmd.py --out runs/v2 --no_adapter # исходная модель (для сравнения)
  python eval_cmd.py --out runs/v2 --ask "Поставь блок stone на 0 64 0"
  python eval_cmd.py --out runs/v2 --chat
"""
import argparse
import json
import os
import re
from collections import defaultdict

import torch
import transformers
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


def norm_lines(s):
    return [" ".join(l.split()) for l in s.strip().split("\n") if l.strip()]


def mask_text(s, prompt):
    """Тексты в кавычках, которых нет в запросе, придуманы автором: не сравниваем их содержимое."""
    return re.sub(r'"([^"]*)"', lambda m: m.group(0) if m.group(1) in prompt else '"…"', s)


def score(ref, got):
    """(точное совпадение, доля верных строк из эталона)"""
    r, g = norm_lines(ref), norm_lines(got)
    exact = r == g
    line = sum(1 for x in r if x in set(g)) / max(len(r), 1)
    return exact, line


def interleave(rows, n):
    """Берёт примеры по кругу из каждой категории, чтобы в проверку попали все."""
    groups = defaultdict(list)
    for r in rows:
        groups[r.get("category") or (r.get("metadata") or {}).get("category", "?")].append(r)
    out, i = [], 0
    while len(out) < n and any(groups.values()):
        for k in sorted(groups, key=lambda s: sum(map(ord, s)) * 7919 % 1009):
            if groups[k] and len(out) < n:
                out.append(groups[k].pop(0))
        i += 1
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="runs/v2")
    ap.add_argument("--n", type=int, default=60)
    ap.add_argument("--file", default="", help="другой файл проверки, например data/gold_eval.jsonl")
    ap.add_argument("--max_new", type=int, default=400)
    ap.add_argument("--no_adapter", action="store_true")
    ap.add_argument("--ask", default="")
    ap.add_argument("--chat", action="store_true")
    args = ap.parse_args()
    transformers.logging.set_verbosity_error()

    meta = json.load(open(os.path.join(args.out, "meta.json"), encoding="utf-8"))
    tok = AutoTokenizer.from_pretrained(meta["model"])
    model = AutoModelForCausalLM.from_pretrained(
        meta["model"], torch_dtype=torch.bfloat16 if meta.get("dtype") == "bf16" else torch.float32)
    ckw = {"enable_thinking": False} if meta.get("no_think") else {}
    if not args.no_adapter:
        model = PeftModel.from_pretrained(model, os.path.join(args.out, "adapter")).merge_and_unload()
    model.eval()

    def ask(user):
        turns = user if isinstance(user, list) else [{"role": "user", "content": user}]
        msgs = ([{"role": "system", "content": meta["system"]}] if meta["system"] else []) + turns
        text = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True, **ckw)
        x = tok(text, return_tensors="pt", add_special_tokens=False)
        with torch.no_grad():
            y = model.generate(**x, max_new_tokens=args.max_new, do_sample=False)
        return tok.decode(y[0][x["input_ids"].shape[1]:], skip_special_tokens=True).strip()

    if args.ask:
        print(ask(args.ask))
        raise SystemExit

    if args.chat:
        print("Готово! Пиши задачу по-русски, например: Поставь блок stone на координаты 0 64 0")
        print("Пустая строка или Ctrl+D - выход.\n")
        while True:
            try:
                q = input("Ты: ").strip()
            except EOFError:
                break
            if not q:
                break
            print("Модель:\n" + ask(q) + "\n")
        raise SystemExit

    all_rows = [json.loads(l) for l in open(args.file or os.path.join(args.out, "val.jsonl"), encoding="utf-8")]
    rows = interleave(all_rows, args.n)
    ok, ok_m, line_sum = 0, 0, 0.0
    per = defaultdict(lambda: [0, 0, 0.0, 0])
    misses = []
    for i, r in enumerate(rows, 1):
        convo = [m for m in r["messages"][:-1] if m["role"] != "system"]
        user = " ".join(m["content"] for m in convo if m["role"] == "user")
        ref = r["messages"][-1]["content"]
        got = ask(convo)
        if not ref.lstrip().startswith("/"):   # эталон без команды (отказ/уточнение): главное не выдумать команду
            exact = exact_m = not got.lstrip().startswith("/")
            line = line_m = float(exact)
        else:
            exact, line = score(ref, got)
            exact_m, line_m = score(mask_text(ref, user), mask_text(got, user))
        ok += exact
        ok_m += exact_m
        line_sum += line_m
        cat = r.get("category") or (r.get("metadata") or {}).get("category", "?")
        per[cat][0] += exact
        per[cat][1] += 1
        per[cat][2] += line_m
        per[cat][3] += exact_m
        if not exact_m and len(misses) < 8:
            misses.append((user, ref, got))
        print(f"\r{i}/{len(rows)}", end="", flush=True)
    n = len(rows)
    print(f"\n\nТочное совпадение (строго, до символа): {ok}/{n} = {100 * ok / n:.1f}%")
    print(f"Точное по структуре (без придуманных текстов): {ok_m}/{n} = {100 * ok_m / n:.1f}%")
    print(f"Верных строк по структуре (в среднем): {100 * line_sum / n:.1f}%")
    print("\nПо категориям (структурно верно / верных строк):")
    for c, (a, b, ls, am) in sorted(per.items(), key=lambda kv: kv[1][3] / kv[1][1]):
        print(f"  {am}/{b}  {100 * ls / b:.0f}%  {c}")
    print("\nПримеры ошибок (по структуре):")
    for u, ref, got in misses:
        print(f"- {u[:200]}\n  надо:\n    " + "\n    ".join(ref.split("\n")[:8]) +
              "\n  модель:\n    " + "\n    ".join(got.split("\n")[:8]))

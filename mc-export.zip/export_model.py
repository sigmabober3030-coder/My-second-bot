#!/usr/bin/env python3
"""Сливает LoRA-адаптер с базовой моделью и сохраняет обычную модель (bf16) + файлы для Ollama."""
import argparse
import json
import os
import shutil

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

MODELFILE = '''FROM ./mc-bedrock-q8_0.gguf
SYSTEM "__SYSTEM__"
TEMPLATE """{{ if .System }}<|im_start|>system
{{ .System }}<|im_end|>
{{ end }}<|im_start|>user
{{ .Prompt }}<|im_end|>
<|im_start|>assistant
"""
PARAMETER stop "<|im_end|>"
PARAMETER temperature 0
PARAMETER num_predict 400
'''

ap = argparse.ArgumentParser()
ap.add_argument("--run", required=True, help="папка обучения, например runs/v2")
ap.add_argument("--out", default="export")
args = ap.parse_args()

meta = json.load(open(os.path.join(args.run, "meta.json"), encoding="utf-8"))
print("Загружаю базовую модель:", meta["model"])
tok = AutoTokenizer.from_pretrained(meta["model"])
model = AutoModelForCausalLM.from_pretrained(meta["model"], torch_dtype=torch.float32)
model = PeftModel.from_pretrained(model, os.path.join(args.run, "adapter")).merge_and_unload()
model = model.to(torch.bfloat16)

dst = os.path.join(args.out, "merged")
os.makedirs(dst, exist_ok=True)
model.save_pretrained(dst, safe_serialization=True)
tok.save_pretrained(dst)
shutil.copytree(os.path.join(args.run, "adapter"), os.path.join(args.out, "adapter"), dirs_exist_ok=True)
json.dump(meta, open(os.path.join(args.out, "meta.json"), "w", encoding="utf-8"), ensure_ascii=False)
open(os.path.join(args.out, "Modelfile"), "w", encoding="utf-8").write(
    MODELFILE.replace("__SYSTEM__", meta["system"].replace('"', "'")))
print("Готово:", args.out)
